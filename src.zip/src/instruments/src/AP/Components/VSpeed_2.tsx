import React from 'react';
import { useSimVar } from '../../Hooks/simVars';

export const VSpeed_2 = () => {
    
    return(
        <g>

            <text x={499} y={982}  fontSize={24} className='ESIS'>0</text>
            <text x={499} y={927}  fontSize={20} className='ESIS'>1</text>
            <text x={499} y={900}  fontSize={20} className='ESIS'>2</text>
            <text x={499} y={875}  fontSize={20} className='ESIS'>3</text>

            <text x={499} y={1034}  fontSize={20} className='ESIS'>1</text>
            <text x={499} y={1060}  fontSize={20} className='ESIS'>2</text>
            <text x={499} y={1087}  fontSize={20} className='ESIS'>3</text>


            <rect x={478} y={1083} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={1069} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={1055} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={1042} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={1030} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={1015} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={1001} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={984} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={970} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={957} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={943} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={929} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={916} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={902} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={890} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={875} width={15} height={4} className='YellowVS'/>
            <rect x={478} y={861} width={15} height={4} className='YellowVS'/>
        </g>
    )
};
