import React from 'react';
import './emergency.scss';

export const Emergency = () => {
	return (
		<div className="emergencyContainer">
			<h1>emergency</h1>
		</div>
	);
};
