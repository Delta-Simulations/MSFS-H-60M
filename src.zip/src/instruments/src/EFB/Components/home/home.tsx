import React from 'react';
import './home.scss';

export const Home = () => {
	return (
		<div className="homeContainer">
			
		</div>
	);
};
