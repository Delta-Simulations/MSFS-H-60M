import React from 'react';

export const Browser = () => {
	return (
		<iframe
			width="1040"
			height="750"
			src="https://www.bing.com/"
			frameborder="0"
		></iframe>
	);
};
