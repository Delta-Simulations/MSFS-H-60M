Version 1.5 readme

This version brings several improvement from previous versions:

1. Fixed a 1 line of code (...) bug in the stabilizers that will make the helicopter more stable in forward and lateral flight, DUE TO THIS MINOR CHANGE HELICOPTER WILL FLY QUITE DIFFERENTLY, YOU MIGHT HAVE TO ADJUST EXISTING PROFILES

2. Improved the automatic reading of config files also for profiles using ATC special characters, please see the manual on
page 2.

3. To map your rotor rpm gauge use Simvar "TAILHOOK POSITION" 

4. Governor support: Use Simvar = "AUTO COORDINATION" true/false for GovernorOn/off.

5. Governor power input use Simvar  "GENERAL ENG PROPELLER LEVER POSITION:1"


thanks !
Fred

